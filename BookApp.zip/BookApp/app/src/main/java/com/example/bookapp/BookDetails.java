package com.example.bookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class BookDetails extends AppCompatActivity {

    String bookTitle,bookprice,bookIsbn,bookCategorie,description;
    byte[]image;
    TextView tvTitle,tvPrix,tvIsbn,tvCategory,tvDescription;
    ImageView imgBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);

        Init();
        Intent i = getIntent();
        image = i.getByteArrayExtra("image");
        bookTitle=i.getStringExtra("titre");
        bookprice = i.getStringExtra("prix");
        bookIsbn = i.getStringExtra("isbn");
        bookCategorie=i.getStringExtra("catego");
        description = i.getStringExtra("description");

        //Toast.makeText(BookDetails.this,bookCategorie,Toast.LENGTH_SHORT).show();

       Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);
       imgBook.setImageBitmap(bitmap);

        tvTitle.setText(bookTitle);
        tvPrix.setText(bookprice);
        tvIsbn.setText(bookIsbn);
        tvCategory.setText(bookCategorie);
        tvDescription.setText(description);


    }

    public void Init(){

        tvTitle = findViewById(R.id.infosLivre_tv_titre);
        tvPrix = findViewById(R.id.infosLivre_tv_prix);
        tvIsbn = findViewById(R.id.infosLivre_tv_isbn);
        tvCategory = findViewById(R.id.infosLivre_tv_categorie);
        tvDescription = findViewById(R.id.infosLivre_tv_description);
        imgBook = findViewById(R.id.infosDetails_ImageBook);

    }
}
