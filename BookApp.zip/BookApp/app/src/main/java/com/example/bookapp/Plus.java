package com.example.bookapp;


import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageActivity;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 */
public class Plus extends Fragment {

    private DBhelper db;
    private ArrayList<String>category;
    private EditText EbookTitle,EbookIsbn,EbookPrice,EbookDetails;
    private Spinner sp;
    private User user;
    private Book book;
    private Post post;
    private Main mainActivity;
    private Button btnUpload;
    private String bookTitle,bookIsbn,bookDetails,bookPrice;
    private String text,categorie;
    // Information temporelle
    private Calendar calendar;
    private SimpleDateFormat simpleDateFormat;
    private String date,time,dateAndtime;
    private Category c;
    // image
    private ImageView imgv;
    private static final int CAMERA_REQUEST_CODE=100;
    private static final int STORAGE_REQUEST_CODE=101;
    private static final int IMAGE_PICK_CAMERA_CODE=102;
    private static final int GALLERY_CODE_REQUEST=103;

    private String[] cameraPermissions;
    private String[] storagePermission;
    private String[]GalleryPermission;
    private Uri imageUri;


    public Plus() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment__plus, container, false);
        Init(view);

        if(user!=null){

            Upload();
            /*String pseudo = user.getPseudo();
            MakeToast(pseudo);*/
        }

        cameraPermissions = new String[]{
            Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        storagePermission = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        GalleryPermission = new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE
        };
        imgv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                imagePickDialog();
                /*requestPermissions(
                    storagePermission, GALLERY_CODE_REQUEST
                );*/
            }
        });
        return view;
    }

    private void imagePickDialog(){

        String[]options = {"Camera","Gallerie"};

        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        builder.setTitle("Sélectionnez votre image");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if(which==0){
                    // if 0 open camera and check permission
                    if(!checkCameraPermission()){
                        //if permission not granted, request!
                        requestCameraPermission();
                    }else{

                        pickFromCamera();
                    }
                }else if(which==1){

                    if(!checkStoragePermission()){
                        requestStoragePermission();
                    }else{

                        pickFromStorage();
                    }
                }
            }

        });
        builder.create().show();
    }//choix de la photo

    private void pickFromStorage(){

        Intent gallery = new Intent(Intent.ACTION_PICK);
        gallery.setType("image/*");
        startActivityForResult(gallery,GALLERY_CODE_REQUEST);

    }
    private void pickFromCamera(){

        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.TITLE,"Titre image");
        cv.put(MediaStore.Images.Media.DESCRIPTION,"Description image");

        imageUri = getActivity().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);

        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        camera.putExtra(MediaStore.EXTRA_OUTPUT,imageUri);
        startActivityForResult(camera,IMAGE_PICK_CAMERA_CODE);
    }

    private boolean checkStoragePermission(){

        boolean result = ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestStoragePermission(){

        requestPermissions(storagePermission,STORAGE_REQUEST_CODE);

    }

    private boolean checkCameraPermission(){

        boolean result = ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.CAMERA)
                ==(PackageManager.PERMISSION_GRANTED);

        boolean result1 = ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    private void requestCameraPermission(){

        requestPermissions(cameraPermissions,CAMERA_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

       /* if(requestCode==GALLERY_CODE_REQUEST&&resultCode == Activity.RESULT_OK && data!=null){

            Uri uri = data.getData();
            try {
                InputStream inputStream = getActivity().getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgv.setImageBitmap(bitmap);
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }*/
        if(resultCode == Activity.RESULT_OK){

            if(requestCode==GALLERY_CODE_REQUEST){

                CropImage.activity(data.getData())
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1,1)
                        .start(getContext(),this);

            }else if(requestCode==IMAGE_PICK_CAMERA_CODE){

                CropImage.activity(imageUri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1,1)
                        .start(getContext(),this);
            }else if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){

                CropImage.ActivityResult result = CropImage.getActivityResult(data);

                if(resultCode == Activity.RESULT_OK){

                    Uri resultUri = result.getUri();
                    imageUri = resultUri;
                    imgv.setImageURI(resultUri);


                }else if(resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){

                    Exception error = result.getError();
                    MakeToast(""+error);
                }
            }
        }
    }

    /*@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == GALLERY_CODE_REQUEST){

            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,GALLERY_CODE_REQUEST);
            }else{
                text="vous n'avez pas la permission";
                MakeToast(text);
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
    }*/


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){

            case CAMERA_REQUEST_CODE:{

                if(grantResults.length>0){

                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted =grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if(cameraAccepted && storageAccepted){

                        pickFromCamera();
                    }else{

                        text="Autorisez l'accès à la caméra";
                        MakeToast(text);
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE:{

                if(grantResults.length>0){

                    boolean storageAccpeted = grantResults[0]== PackageManager.PERMISSION_GRANTED;

                    if(storageAccpeted){

                        pickFromStorage();
                    }else{

                        text="Autorisez l'accès au stockage";
                        MakeToast(text);
                    }
                }
            }
        }
    }

    public void Init(View view){
        db = new DBhelper(getContext());
        sp = view.findViewById(R.id.spinner);
        EbookTitle = view.findViewById(R.id.edtxt_title);
        EbookIsbn = view.findViewById(R.id.edtxt_codeIsbn);
        EbookPrice = view.findViewById(R.id.edtxt_price);
        EbookDetails = view.findViewById(R.id.edtxt_description);
        btnUpload = view.findViewById(R.id.btn_uplaod);
        imgv = view.findViewById(R.id.imgv_mybook);
        btnUpload.setEnabled(false);
        btnUpload.setBackgroundResource(R.color.darkInput);

        EbookTitle.addTextChangedListener(uploadInputextWatcher);
        EbookIsbn.addTextChangedListener(uploadInputextWatcher);
        EbookPrice.addTextChangedListener(uploadInputextWatcher);
        EbookDetails.addTextChangedListener(uploadInputextWatcher);

        mainActivity = (Main)getActivity();
        user = mainActivity.getUserFromMain();

        //Recuperer catégorie de la DB
        category = db.getCatégorie();
        ArrayAdapter<String>adapter = new ArrayAdapter<String>(
                getContext(),
                android.R.layout.simple_list_item_1,
                category);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                categorie = parent.getItemAtPosition(position).toString();
                text=categorie+" sélectionnée";
                MakeToast(text);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public TextWatcher uploadInputextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            String title,isbn,price,details;
            title = EbookTitle.getText().toString().trim();
            isbn =  EbookIsbn.getText().toString().trim();
            price = EbookPrice.getText().toString().trim();
            details=EbookDetails.getText().toString().trim();


            if(!title.isEmpty()&&!isbn.isEmpty()&&!price.isEmpty()&& !details.isEmpty()){

                btnUpload.setEnabled(true);
                btnUpload.setBackgroundResource(R.color.input);
            }

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void MakeToast(String text){

        Context c = getContext();
        int duration = Toast.LENGTH_SHORT;
        Toast t  = Toast.makeText(c,text,duration);
        t.show();
    }

    public void setTime(){
        calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
        date = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        time=simpleDateFormat.format(calendar.getTime());
        dateAndtime=date+";"+time;
    }

    public void Upload(){

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookTitle=EbookTitle.getText().toString().trim();
                bookIsbn = EbookIsbn.getText().toString().trim();
                bookPrice  =EbookPrice.getText().toString().trim();
                bookDetails=EbookDetails.getText().toString().trim();


                /*if(!bookTitle.isEmpty()&&!bookIsbn.isEmpty()&&!bookPrice.isEmpty()&&!bookDetails.isEmpty()){*/

                    /*if(){*/
                        float fbookPrice = Float.parseFloat(bookPrice);
                        c =db.getIdCategory(categorie);//get id de categorie choisie
                    /*text="l'id "+c.getsId();
                    MakeToast(text);*/

                    if(imageUri!=null){
                        byte[]image=imageviewtoByte(imgv);
                        book = new Book(bookTitle,bookIsbn,fbookPrice,bookDetails,c.getsId(),image);

                        long id =db.addBook(book);

                        if(id!=-1){
                            text="Livre ajouté";
                            MakeToast(text);
                            //int idBook = db.getBookId(book);

                            setTime();
                            post = new Post(user,id,dateAndtime);
                            Boolean createpost = db.addPost(post);
                            if(createpost){
                                toSeeBook();
                            }else{
                                text="Echec création du livre";
                                MakeToast(text);
                            }

                        }else{
                            text="Echec de l'ajout du livre";
                            MakeToast(text);
                        }
                    }else{

                        text="Pas d'image";
                        MakeToast(text);
                    }



                /*}*/
            }
        });
    }

    public void toSeeBook(){

        Fragment post = new SeeBook();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, post).commit();
    }

    private byte[] imageviewtoByte(ImageView img){
        Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
        byte[]byteArray = stream.toByteArray();
        return byteArray;
    }

    private Bitmap decodeUriAsBitmap(Uri uri){
        Bitmap bitmap;
        try {
            bitmap = BitmapFactory.decodeStream(getActivity().getContentResolver().openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }





}
