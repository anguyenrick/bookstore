package com.example.bookapp;

public class Post {

    private String sDate;
    private User user;
    private Book book;
    private long idBook;

    public Post(User u,Book b,String date){

        this.user = u;
        this.book = b;
        this.sDate =date;
    }

    public Post(User u,long idBook,String date){

        this.user = u;
        this.idBook = idBook;
        this.sDate =date;
    }

    public long getlId(){
        return idBook;
    }


    public User getUser(){

        return user;
    }

    public Book getBook(){
        return  book;
    }

    public String getsDate(){

        return sDate;
    }
}
