package com.example.bookapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.ArrayList;

public class EditBookDetails extends AppCompatActivity {

    String bookTitle,bookprice,bookIsbn,bookCategorie,description,id;
    byte[]image;
    ImageView imgv;
    EditText edtxtTitle,edtxtPrix,edtxtCategory,edtxtDescription,edtxtIsbn;
    Button btnSave,btnDelete;
    private User user;
    private Main mainactivity;
    private DBhelper db;
    private Book b;
    private Spinner sp;
    private Category c;
    private ArrayList<String> listcategory;
    String categorie,text;
    private static final int CAMERA_REQUEST_CODE=100;
    private static final int STORAGE_REQUEST_CODE=101;
    private static final int IMAGE_PICK_CAMERA_CODE=102;
    private static final int GALLERY_CODE_REQUEST=103;

    private String[] cameraPermissions;
    private String[] storagePermission;
    private String[]GalleryPermission;
    private Uri imageUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_book_details);
        Init();

        cameraPermissions = new String[]{
                    Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
        storagePermission = new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
        GalleryPermission = new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            };
            imgv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    imagePickDialog();
                /*requestPermissions(
                    storagePermission, GALLERY_CODE_REQUEST
                );*/
                }
            });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(EditBookDetails.this);
                builder.setTitle("Mise à jour du livre");
                builder.setMessage("Etes-vous sûr de vouloir mettre à jour le livre?");
                builder.setCancelable(false);

                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        String titre = edtxtTitle.getText().toString().trim();
                        String Price = edtxtPrix.getText().toString().trim();
                        String description = edtxtDescription.getText().toString().trim();
                        String isbn = edtxtIsbn.getText().toString().trim();
                        float price = Float.parseFloat(Price);


                        if(imageUri!=null){
                            // id nouvelle categorie selectionnée
                            c = db.getIdCategory(categorie);
                            b = new Book(titre,isbn,price,description,c.getsId(),image);
                            boolean update = db.updateBook(id,b);

                            if(update){
                                Intent i = new Intent(EditBookDetails.this,Main.class);
                                i.putExtra("userDetails",user);
                                startActivity(i);
                            }else{

                                text="Echec de la mise à jour";
                                MakeToast(text);
                            }
                        }else{
                            text="Veuillez sélectionner une image";
                            MakeToast(text);
                        }


                    }
                });

                builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.create().show();

            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(EditBookDetails.this);
                builder.setTitle("Suppression du livre "+bookTitle);
                builder.setMessage("Etes-vous sûr de vouloir supprimer ce livre?");
                builder.setCancelable(false);

                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Boolean deleteBook = db.deleteBook(id);
                        if(deleteBook){
                            text="Livre supprimé";
                            MakeToast(text);
                            Intent i = new Intent(EditBookDetails.this,Main.class);
                            i.putExtra("userDetails",user);
                            startActivity(i);
                        }else{
                            text="Suppression non réussie";
                            MakeToast(text);
                        }

                    }
                });

                builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.create().show();
            }
        });



    }

    public TextWatcher editTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            String titre = edtxtTitle.getText().toString().trim();
            String prix = edtxtPrix.getText().toString().trim();
            String details = edtxtDescription.getText().toString().trim();
            String isbn = edtxtIsbn.getText().toString().trim();
            if(!titre.isEmpty()&&!prix.isEmpty()&&!details.isEmpty()&&!isbn.isEmpty()){
                btnSave.setEnabled(true);
                btnSave.setBackgroundResource(R.color.input);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void Init()
    {



        edtxtTitle = findViewById(R.id.edit_infosLivre_tv_titre);
        edtxtPrix = findViewById(R.id.edit_infosLivre_tv_prix);
        sp = findViewById(R.id.edit_infosLivre_sp_categorie);
        edtxtDescription = findViewById(R.id.edit_infosLivre_tv_description);
        edtxtIsbn = findViewById(R.id.edit_infosLivre_tv_isbn);
        imgv = findViewById(R.id.edit_infosDetails_ImageBook);
        btnSave = findViewById(R.id.edit_book_btn_edit);
        btnDelete = findViewById(R.id.btn_edit_delete_book);

        btnSave.setEnabled(false);
        btnSave.setBackgroundResource(R.color.darkInput);

        //Recuperation des infos de la page précédente
        Intent i = getIntent();
        user = (User)i.getSerializableExtra("userDetails");//GET USER!!!!!!
        image = i.getByteArrayExtra("image");
        bookTitle=i.getStringExtra("titre");
        bookprice = i.getStringExtra("prix");
        bookIsbn = i.getStringExtra("isbn");
        bookCategorie=i.getStringExtra("catego");
        description = i.getStringExtra("description");
        id = i.getStringExtra("id");

        //Ajout textwatcher sur les input
        edtxtTitle.addTextChangedListener(editTextWatcher);
        edtxtPrix.addTextChangedListener(editTextWatcher);
        edtxtDescription.addTextChangedListener(editTextWatcher);
        edtxtIsbn.addTextChangedListener(editTextWatcher);

        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);
        imgv.setImageBitmap(bitmap);

        //set les view de la page actuelle
        edtxtTitle.setText(bookTitle);
        edtxtPrix.setText(bookprice);
        edtxtDescription.setText(description);
        edtxtIsbn.setText(bookIsbn);
        db = new DBhelper(this);

        //recuperer l'id pour afficher la bonne catégorie
        c=db.getIdCategory(bookCategorie);
        //Recuperer catégorie de la DB
        listcategory = db.getCatégorie();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                listcategory);
        sp.setAdapter(adapter);
        //set l'id récupéré
        sp.setSelection(c.getsId()-1);//car il y a un décalage de 1 avec les positions du spinner
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                categorie = parent.getItemAtPosition(position).toString();
                text=categorie+" sélectionnée";
                MakeToast(text);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    public void MakeToast(String text){

        Context c = this;
        int duration = Toast.LENGTH_SHORT;
        Toast t  = Toast.makeText(c,text,duration);
        t.show();
    }

    private void imagePickDialog(){

        String[]options = {"Camera","Gallerie"};

        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        builder.setTitle("Sélectionnez votre image");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if(which==0){
                    // if 0 open camera and check permission
                    if(!checkCameraPermission()){
                        //if permission not granted, request!
                        requestCameraPermission();
                    }else{

                        pickFromCamera();
                    }
                }else if(which==1){

                    if(!checkStoragePermission()){
                        requestStoragePermission();
                    }else{

                        pickFromStorage();
                    }
                }
            }

        });
        builder.create().show();
    }//choix de la photo

    private void pickFromStorage(){

        Intent gallery = new Intent(Intent.ACTION_PICK);
        gallery.setType("image/*");
        startActivityForResult(gallery,GALLERY_CODE_REQUEST);

    }
    private void pickFromCamera(){

        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.TITLE,"Titre image");
        cv.put(MediaStore.Images.Media.DESCRIPTION,"Description image");

        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);

        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        camera.putExtra(MediaStore.EXTRA_OUTPUT,imageUri);
        startActivityForResult(camera,IMAGE_PICK_CAMERA_CODE);
    }

    private boolean checkStoragePermission(){

        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestStoragePermission(){

        ActivityCompat.requestPermissions(this,storagePermission,STORAGE_REQUEST_CODE);

    }

    private boolean checkCameraPermission(){

        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)
                ==(PackageManager.PERMISSION_GRANTED);

        boolean result1 = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    private void requestCameraPermission(){

        ActivityCompat.requestPermissions(this,cameraPermissions,CAMERA_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == GALLERY_CODE_REQUEST) {

                CropImage.activity(data.getData())
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1, 1)
                        .start(this);

            } else if (requestCode == IMAGE_PICK_CAMERA_CODE) {

                CropImage.activity(imageUri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1, 1)
                        .start(this);
            } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {

                CropImage.ActivityResult result = CropImage.getActivityResult(data);

                if (resultCode == Activity.RESULT_OK) {

                    Uri resultUri = result.getUri();
                    imageUri = resultUri;
                    imgv.setImageURI(resultUri);

                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                    Exception error = result.getError();
                    MakeToast("" + error);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){

            case CAMERA_REQUEST_CODE:{

                if(grantResults.length>0){

                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted =grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if(cameraAccepted && storageAccepted){

                        pickFromCamera();
                    }else{

                        text="Autorisez l'accès à la caméra";
                        MakeToast(text);
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE:{

                if(grantResults.length>0){

                    boolean storageAccpeted = grantResults[0]== PackageManager.PERMISSION_GRANTED;

                    if(storageAccpeted){

                        pickFromStorage();
                    }else{

                        text="Autorisez l'accès au stockage";
                        MakeToast(text);
                    }
                }
            }
        }
    }

}
