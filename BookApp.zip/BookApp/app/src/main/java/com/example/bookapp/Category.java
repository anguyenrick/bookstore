package com.example.bookapp;

public class Category {


    int sId;
    String sLibelle;

    public Category(int id,String libellé){

        this.sId=id;
        this.sLibelle=libellé;
    }

    public int getsId() {
        return sId;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public String getsLibellé() {
        return sLibelle;
    }

    public void setsLibellé(String sLibellé) {
        this.sLibelle = sLibellé;
    }


}
