package com.example.bookapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main extends AppCompatActivity {

    private User user;
    private String admin,pwd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        BottomNavigationView btNav;

        admin = "admin";
        pwd = "adminpwd";
        btNav=findViewById(R.id.nav_bottom);
        btNav.setOnNavigationItemSelectedListener(navListener);

        //Affichage des livres d'abord
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new SeeBook()).commit();

        // Recuperer le user connecté ou de l'admin qui retourne à la page principal
        Intent i = getIntent();
        user = (User) i.getSerializableExtra("userDetails");
        //Toast.makeText(this,user.getMail(),Toast.LENGTH_LONG);




        //getSupportFragmentManager().beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.container, selectedFragment).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                    Fragment selectedFragment=null;

                    switch (item.getItemId()){

                        case R.id.nav_profil:
                            if(user.getMail().equals(admin)&&user.getPassword().equals(pwd)){
                                selectedFragment=new PlusAdmin();
                            }else {
                                selectedFragment = new Profil();
                            }
                             break;
                        case R.id.nav_home:
                            selectedFragment=new SeeBook();
                            break;
                        case R.id.nav_plus:
                                selectedFragment=new Plus();
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
                    return true;
                }
            };
    public User getUserFromMain(){

        return user;
    }

}
