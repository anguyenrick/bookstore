package com.example.bookapp;

import java.io.Serializable;

public class User implements Serializable{

    private String sId,sMail,sPseudo,sPassword,sPhone,sAdress;


    public User(String email,String identif,String pwd,String telephone,String adressedom){

        this.sMail = email;
        this.sPseudo = identif;
        this.sPassword= pwd;
        this.sPhone = telephone;
        this.sAdress = adressedom;
    }

    public User(String mail,String pwd){//admin

        this.sMail = mail;
        this.sPassword = pwd;
        this.sId="0";
    }

    public String getId(){
        return sId;
    }
    public void setId(String identifiant){
        this.sId = identifiant;
    }

    public String getMail(){

        return sMail;
    }

    public String getPseudo(){

        return sPseudo;
    }

    public String getPhone(){

        return sPhone;
    }

    public String getPassword(){

        return sPassword;
    }

    public String getAdress(){

        return sAdress;
    }

    /*public void setMail(String mail) {
        this.mail = mail;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }*/


}
