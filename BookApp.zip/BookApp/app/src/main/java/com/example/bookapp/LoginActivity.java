package com.example.bookapp;

import android.app.Activity;

import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bookapp.DBhelper;
import com.example.bookapp.Forgot_Password;
import com.example.bookapp.MainActivity;
import com.example.bookapp.R;
//import com.example.bookapp.ui.login.LoggedInUserView;
import com.example.bookapp.ui.login.LoginViewModel;
import com.example.bookapp.ui.login.LoginViewModelFactory;

public class LoginActivity extends AppCompatActivity {

    private LoginViewModel loginViewModel;
    private TextView tvForgotPw;
    private DBhelper db;
    private EditText Eemail,Epwd;
    private Button btnSubmitLogin;
    private User user;
    private String textToast;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        Eemail = findViewById(R.id.input_mail);
        Epwd = findViewById(R.id.input_pw);
        btnSubmitLogin = findViewById(R.id.btn_login);
        btnSubmitLogin.setEnabled(false);
        btnSubmitLogin.setBackgroundResource(R.color.darkInput);
        db = new DBhelper(this);

        Eemail.addTextChangedListener(loginTextWatcher);
        Epwd.addTextChangedListener(loginTextWatcher);

        btnSubmitLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = Eemail.getText().toString().trim();
                String pwd = Epwd.getText().toString().trim();
                //admin
                String admin="admin";
                String adminpwd="adminpwd";

                 Boolean checkLP = db.CheckloginPwd(mail,pwd);//check login and pwd


                if(mail.equals(admin) && pwd.equals(adminpwd)){

                    user = new User(mail,pwd);
                    Intent intent = new Intent(LoginActivity.this, Main.class);
                    intent.putExtra("userDetails",user);
                    startActivity(intent);
                    /*textToast=" Bienvenue "+user.getPseudo();
                    MakeToast(textToast);*/

                }else{

                    if(mail.contains("@")){

                        if(checkLP==true){


                            user = db.login(mail,pwd);
                            Intent intent = new Intent(LoginActivity.this, Main.class);
                            intent.putExtra("userDetails",user);
                            startActivity(intent);
                            textToast=" Bienvenue "+user.getPseudo();
                            MakeToast(textToast);


                        }else{
                            textToast=" Identifiant ou mot de passe erroné! Etes-vous inscrit?";
                            MakeToast(textToast);
                            Eemail.setText(null);
                            Epwd.setText(null);
                        }
                    }else {

                        textToast="Email non valide";
                        MakeToast(textToast);
                    }



                }


            }
        });
       // final ProgressBar loadingProgressBar = findViewById(R.id.loading);


        /*loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                }
                setResult(Activity.RESULT_OK);

                //Complete and destroy login activity once successful
                finish();
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());
                }
                return false;
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                loginViewModel.login(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        });*/

        // Start fragment from activity

        tvForgotPw = findViewById(R.id.tv_forgot_pw);

        tvForgotPw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Forgot_Password fgPw = new Forgot_Password();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, fgPw).commit();
                //transaction.commit();
            }
        });


    }

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            String login = Eemail.getText().toString().trim();
            String pwd = Epwd.getText().toString().trim();

            if(!login.isEmpty()&&!pwd.isEmpty()){
                btnSubmitLogin.setBackgroundResource(R.color.input);
                btnSubmitLogin.setEnabled(true);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };


    /*private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }*/

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    public void ToSignIn(View view){

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

   /* public void ToMain(View view,User user){

        Intent intent = new Intent(this, Main.class);
        intent.putExtra("userDétails",user);
        startActivity(intent);
    }*/

    public void MakeToast(CharSequence text){

        Context c = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        Toast t = Toast.makeText(c,text,duration);
        t.show();
    }
}
