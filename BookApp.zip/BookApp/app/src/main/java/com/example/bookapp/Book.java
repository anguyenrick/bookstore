package com.example.bookapp;


public class Book {

    private String sId;
    private String sTitle;
    private String sISBN;
    private String sDescription;
    private String sImage;
    private byte []btImage;
    private int iQuantité;
    private int iCategory;
    private float fPrice;


    /*public Book(String title,String isbn, float price,String description,int category,String image){

        this.sTitle=title;
        this.sISBN = isbn;
        this.fPrice = price;
        this.sDescription = description;
        this.iCategory = category;
        this.sImage = image;
    }*/

    public Book(String id,String title,String isbn, float price,String description,int category,byte[] image){

        this.sId=id;
        this.sTitle=title;
        this.sISBN = isbn;
        this.fPrice = price;
        this.sDescription = description;
        this.iCategory = category;
        this.btImage = image;
    }


    public Book(String title,String isbn, float price,String description,int category,byte[] image){

        this.sTitle=title;
        this.sISBN = isbn;
        this.fPrice = price;
        this.sDescription = description;
        this.iCategory = category;
        this.btImage = image;
    }

    public byte[] getBtImage() {
        return btImage;
    }

    public void setBtImage(byte[] btImage) {
        this.btImage = btImage;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String id){
        this.sId = id;
    }

    public String getsDescription() {
        return sDescription;
    }

    public void setsDescription(String sDescription) {
        this.sDescription = sDescription;
    }

    public int getiCatégory() {
        return iCategory;
    }

    public void setsCatégory(int Catégory) {
        this.iCategory = Catégory;
    }

    public float getfPrice() {
        return fPrice;
    }

    public void setfPrice(float Price) {
        this.fPrice = Price;
    }


    public String getsTitle() {
        return sTitle;
    }

    public void setsTitle(String sTitle) {
        this.sTitle = sTitle;
    }

    public String getsImage() {
        return sImage;
    }

    public void setsImage(String Image) {
        this.sImage = Image;
    }

    public String getsISBN() {
        return sISBN;
    }

    public void setsISBN(String sISBN) {
        this.sISBN = sISBN;
    }

    public int getiQuantité() {
        return iQuantité;
    }

    public void setsQuantité(int Quantité) {
        this.iQuantité = Quantité;
    }


}
