package com.example.bookapp;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class Forgot_Password extends Fragment {


    public Forgot_Password() {
        // Required empty public constructor
    }

    public void MakeToast(CharSequence text){

        Context context = getContext();
        int duration=Toast.LENGTH_SHORT;
        Toast t = Toast.makeText(context,text,duration);
        t.show();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // return inflater.inflate(R.layout.fragment_forgot__password, container, false);

        final EditText Epwforgot;
        final Button btnSubmitforgot;


        View view = inflater.inflate(R.layout.fragment_forgot__password, container, false);
        Epwforgot = view.findViewById(R.id.input_email_pw_forgot);
        btnSubmitforgot = view.findViewById(R.id.btn_submit_pw_forgot);

        btnSubmitforgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!(Epwforgot.getText().toString().isEmpty())){

                    CharSequence text="Mail envoyé";
                    MakeToast(text);

                }else{

                    CharSequence text="Veuillez remplir tous les champs";;
                    MakeToast(text);
                }
            }
        });

        TextView tvCancel = view.findViewById(R.id.tv_annuler);

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }
}


