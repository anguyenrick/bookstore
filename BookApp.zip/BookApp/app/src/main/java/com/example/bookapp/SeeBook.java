package com.example.bookapp;


import android.app.ActionBar;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.badge.BadgeUtils;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.lang.reflect.Type;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class SeeBook extends Fragment {

    private ActionBar actionBar;
    private RecyclerView recyclerView;
    private DBhelper db;
    private User user;
    private Main mainActivity;
    private BadgeDrawable nbrLivre;
    private BottomNavigationView btNav;


    public SeeBook() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_upload, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        db = new DBhelper(getContext());
        btNav = view.findViewById(R.id.nav_bottom);
        //nbrLivre = BadgeDrawable.create(getContext());
        //BadgeUtils.attachBadgeDrawable(nbrLivre,view,null);



        mainActivity = (Main)getActivity();
        user = mainActivity.getUserFromMain();
        showBook();


       // ((AppCompatActivity)getActivity()).getSupportActionBar();
        //actionBar.setTitle("Découvrez des livres");

        /*LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);*/



        return view;
    }

    private void showBook(){

            ArrayList<Object>BookinDB = db.getBook();

            if(BookinDB.size()==0){

                Toast.makeText(getContext(),"Actuellement aucun livre",Toast.LENGTH_SHORT).show();

            }else{
                Adapter adapter = new Adapter(getContext(),BookinDB,user);
                recyclerView.setAdapter(adapter);
                /*nbrLivre = btNav.getOrCreateBadge(R.id.nav_home);
                nbrLivre.setVisible(true);
                nbrLivre.setNumber(adapter.getItemCount());*/
            }

            //adapter.notifyDataSetChanged();

    }

}
