package com.example.bookapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.StrictMode;
import android.widget.Toast;


import androidx.annotation.Nullable;

import java.sql.Connection;
import java.util.ArrayList;

public class DBhelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BookStoreDB";
    private static final String TABLE_USER ="User";
    private static final String COL2 = "Email";//text
    private static final String COL3 = "Pseudo";//
    private static final String COL4 = "Password";//
    private static final String COL5 = "Téléphone";//
    private static final String COL6 = "Adresse";//
    private static final String TABLE_CATEGORIE ="Catégorie";
    private static final String TABLE_LIVRE ="Livre";
    private static final String TABLE_POST ="Post";
    private static final String TABLE_COMMENT ="Commentaire";
    private static ArrayList<String>Catégorie;



    public DBhelper(@Nullable Context context) {
        super(context,DATABASE_NAME,null,1);
        // Constructeur qui crée la DB
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//create table

        String createUser="CREATE TABLE "+TABLE_USER+" (IDUser INTEGER PRIMARY KEY AUTOINCREMENT,"+COL2+" TEXT, "+COL3+" TEXT, "+COL4+" TEXT, "+COL5+" TEXT, "+COL6+" TEXT)";
        String createCategorie="CREATE TABLE "+TABLE_CATEGORIE+"(IDCat INTEGER PRIMARY KEY AUTOINCREMENT,Libellé TEXT)";
        //String createLivre="CREATE TABLE "+TABLE_LIVRE+"(IDLivre INTEGER PRIMARY KEY AUTOINCREMENT,IDCat INTEGER,ISBN TEXT,Nom TEXT,Prix REAL,Quantité INTEGER,Description TEXT,Image TEXT, FOREIGN KEY(IDCat) REFERENCES "+TABLE_USER+"(IDUser))";
        String createLivre="CREATE TABLE "+TABLE_LIVRE+"(IDLivre INTEGER PRIMARY KEY AUTOINCREMENT,IDCat INTEGER,ISBN TEXT,Nom TEXT,Prix REAL,Quantité INTEGER,Description TEXT,Image BLOG, FOREIGN KEY(IDCat) REFERENCES "+TABLE_USER+"(IDUser))";
        String createPost="CREATE TABLE "+TABLE_POST+"(IDPost INTEGER PRIMARY KEY AUTOINCREMENT,idUser INTEGER,idLivre INTEGER,Date TEXT,Description TEXT, FOREIGN KEY(IdUser) REFERENCES "+TABLE_USER+"(IDUSER), FOREIGN KEY (idLivre) REFERENCES "+TABLE_LIVRE+"(iDLivre))";
        String createComment="CREATE TABLE "+TABLE_COMMENT+"(IDCom INTEGER PRIMARY KEY AUTOINCREMENT,idUser INTEGER,idPost INTEGER,Contenu TEXT,Date TEXT, FOREIGN KEY(idUser) REFERENCES "+TABLE_USER+"(IDUSER), FOREIGN KEY (idPost) REFERENCES "+TABLE_POST+"(IDPost))";
        db.execSQL(createUser);
        db.execSQL(createCategorie);
        db.execSQL(createLivre);
        db.execSQL(createPost);
        db.execSQL(createComment);
        String addCatégorie="Insert into "+TABLE_CATEGORIE+"(Libellé) VALUES ('Science-fiction'),('Roman'),('Apprentissage'),('Comique'),('Tragique'),('Policier'),('Romantique')";
        db.execSQL(addCatégorie);
        //db.execSQL("PRAGMA foreign_keys = ON;");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " +TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_CATEGORIE);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_LIVRE);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_POST);
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_COMMENT);

        onCreate(db);
    }
    //String email,String pseudo,String password,String telephone,String adresse
    public boolean addUser(User user){

        SQLiteDatabase db = getWritableDatabase();//écriture dans db
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2,user.getMail());
        contentValues.put(COL3,user.getPseudo());
        contentValues.put(COL4,user.getPassword());
        contentValues.put(COL5,user.getPhone());
        contentValues.put(COL6,user.getAdress());
        long insert = db.insert(TABLE_USER,null,contentValues);


        if(insert==-1)return false;
        else return true;
        //db.close();
    }

    public boolean CheckMail(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+TABLE_USER+" where "+COL2+"=?",new String[]{email});
        if(cursor.getCount()>0)return false;
        else return true;
    }

    public boolean CheckPseudo(String pseudo){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+TABLE_USER+" where "+COL3+"=?",new String[]{pseudo});
        if(cursor.getCount()>0)return false;
        else return true;
    }

    public boolean CheckloginPwd(String email, String password){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+TABLE_USER+" where "+COL2+"=? and "+COL4+"=?",new String[]{email,password});

        return(cursor.getCount()>0);

    }

    //Partie connexion "get user"
    public User login(String email,String password){

                    User user=null;
                    SQLiteDatabase db = getReadableDatabase();
                    Cursor cursor = db.rawQuery("Select * from "+TABLE_USER+" where "+COL2+"=? and "+COL4+"=?",new String[]{email,password});
                    //Cursor cursor = db.rawQuery("Select * from "+TABLE_USER+" where Email=? and Password=? ",new String[]{email,password});

                        if(cursor.moveToFirst()){
                            String id = cursor.getString(0);
                            String Email=cursor.getString(1);
                            String Pseudo=cursor.getString(2);
                            String Password=cursor.getString(3);
                            String Telephone=cursor.getString(4);
                            String Adress=cursor.getString(5);
                            user = new User(Email,Pseudo,Password,Telephone,Adress);
                            user.setId(id);

                        }

                        return user;
    }

    public boolean updateUser(String id,String mail,String pseudo,String pwd,String tel,String adress){

        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2,mail);
        contentValues.put(COL3,pseudo);
        contentValues.put(COL4,pwd);
        contentValues.put(COL5,tel);
        contentValues.put(COL4,adress);
        db.update(TABLE_USER,contentValues, "iDUser = ?",new String[]{id});

        return true;

    }

    public boolean deleteUser(User user){
        SQLiteDatabase db = getWritableDatabase();
        long delete=db.delete(TABLE_USER," iDUser = ?",new String[]{user.getId()});

        return(delete!=-1);

    }

    public boolean addComment(User user/*,Comment comment*/){
        SQLiteDatabase db = getWritableDatabase();
        return true;
    }

    public ArrayList<String>getCatégorie(){//for spinner

        ArrayList<String>listCategory = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        db.beginTransaction();
        String query = "Select * from "+TABLE_CATEGORIE;
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.getCount()>0){
            while (cursor.moveToNext()){
                String catname = cursor.getString(cursor.getColumnIndex("Libellé"));
                listCategory.add(catname);

            }
        }
        db.setTransactionSuccessful();
        db.endTransaction();


        return  listCategory;

    }

    /*public boolean addPost(Post p){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues c =new ContentValues();
        c.put("idUser",p.getUser().getId());
        c.put("idLivre",p.getBook().getsId());
        c.put("Date",p.getsDate());
        long insert= db.insert(TABLE_POST,null,c);


        return (insert!=-1);
    }*/
    public boolean addPost(Post p){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues c =new ContentValues();
        c.put("idUser",p.getUser().getId());
        c.put("idLivre",p.getlId());
        c.put("Date",p.getsDate());
        long insert= db.insert(TABLE_POST,null,c);


        return (insert!=-1);
    }
    /*public boolean addBook(Book b){

        SQLiteDatabase db = getWritableDatabase();
        ContentValues c = new ContentValues();

        c.put("IDCat",b.getiCatégory());
        c.put("ISBN",b.getsISBN());
        c.put("Nom",b.getsTitle());
        c.put("Prix",b.getfPrice());
        c.put("Description",b.getsDescription());
        //c.put("Image",b.getsImage());
        c.put("Image",b.getBtImage());
        b.setsQuantité(1);
        c.put("Quantité",b.getiQuantité());
        long insert = db.insert(TABLE_LIVRE,null,c);
        return(insert!=-1);
    }*/

    public long addBook(Book b){

        SQLiteDatabase db = getWritableDatabase();
        ContentValues c = new ContentValues();

        c.put("IDCat",b.getiCatégory());
        c.put("ISBN",b.getsISBN());
        c.put("Nom",b.getsTitle());
        c.put("Prix",b.getfPrice());
        c.put("Description",b.getsDescription());
        //c.put("Image",b.getsImage());
        c.put("Image",b.getBtImage());
        b.setsQuantité(1);
        c.put("Quantité",b.getiQuantité());
        long id = db.insert(TABLE_LIVRE,null,c);
        return  id;
    }


    public Category getIdCategory(String category){

        Category cat = null;
        SQLiteDatabase db = getReadableDatabase();
        String query = "Select * from "+TABLE_CATEGORIE+" where Libellé = ?";
        Cursor c = db.rawQuery(query,new String[]{category});


        if(c.moveToFirst()){
             int id=c.getInt(c.getColumnIndex("IDCat"));
             cat = new Category(id,category);

        }

        return cat;

    }

    public String getCategoryName(int id){

        String category="";
        SQLiteDatabase db = getReadableDatabase();
        String query = " Select Libellé from "+TABLE_CATEGORIE+" where IDCat = "+id;
        Cursor c =db.rawQuery(query,null);

        if(c.moveToFirst()){

             category = c.getString(c.getColumnIndex("Libellé"));

        }
        return category;
    }

    public ArrayList<Object>getBook(/*String orderby*/){

        ArrayList<Object>listBook = new ArrayList<>();
        String query = "Select * From "+TABLE_LIVRE;/*+" order by "+orderby;DESC=plus récent*/

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(query,null);

        if(c.getCount()>0){

            while (c.moveToNext()){

                int id = c.getInt(c.getColumnIndex("IDLivre"));
                int categorie = c.getInt(c.getColumnIndex("IDCat"));
                String Nom = c.getString(c.getColumnIndex("Nom"));
                String isbn = c.getString(c.getColumnIndex("ISBN"));
                String Prix = c.getString(c.getColumnIndex("Prix"));
                String Quantité = c.getString(c.getColumnIndex("Quantité"));
                String Description = c.getString(c.getColumnIndex("Description"));
                //String image = c.getString(c.getColumnIndex("Image")); avec le URI
                String idBook = Integer.toString(id);
                byte[]image = c.getBlob(c.getColumnIndex("Image"));
                float prix = Float.parseFloat(Prix);
                int quantité = Integer.parseInt(Quantité);
                Book b = new Book(idBook,Nom,isbn,prix,Description,categorie,image);
                b.setsQuantité(quantité);
                listBook.add(b);
            }
        }
        db.close();
        return  listBook;

    }

    public boolean updateBook(String id,Book b){

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        String query="select from "+TABLE_LIVRE+" where IDLivre = ? ";
        cv.put("IDCat",b.getiCatégory());
        cv.put("ISBN",b.getsISBN());
        cv.put("Nom",b.getsTitle());
        cv.put("Prix",b.getfPrice());
        cv.put("Description",b.getsDescription());
        long update = db.update(TABLE_LIVRE,cv,"IDLivre = ?",new String[]{id});
        return(update!=-1);

    }

    public boolean deleteBook(String id){

        SQLiteDatabase db = getWritableDatabase();
        long delete = db.delete(TABLE_LIVRE,"IDLivre = ?",new String[]{id});
        return (delete!=-1);

    }








}




