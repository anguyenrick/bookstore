package com.example.bookapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.Holder> {

    private Context c;
    private ArrayList<Object>ListofObject;
   // private ArrayList<User>ListofUsers;
    private DBhelper db;
    private User user;


    public Adapter(Context c,ArrayList<Object>listeObject,User u) {
        this.c = c;
        this.ListofObject=listeObject;
        this.user=u;
    }

    /*public Adapter(Context c,ArrayList<User>lu,User u){

    }*/

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(c).inflate(R.layout.publication,parent,false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {

        Book book = (Book)ListofObject.get(position);
        db = new DBhelper(c);
        String admin="admin";
        String pwd="adminpwd";

        //Toast.makeText(c,user.getMail(),Toast.LENGTH_SHORT);

        if(user.getMail().equals(admin)&&user.getPassword().equals(pwd)){


            getDetailsBook(holder,book,db,EditBookDetails.class);

        }else{
            /*Book book = (Book)ListofObject.get(position);
            db = new DBhelper(c);*/
            getDetailsBook(holder,book,db,BookDetails.class);


        }

    }

    public void getDetailsBook(Holder holder, Book book, DBhelper db,Class BookDetails){
        final String Id = book.getsId();
        float Price=book.getfPrice();
        int Category=book.getiCatégory();
        final String ISBN=book.getsISBN();
        final String Title=book.getsTitle();
        final String Description=book.getsDescription();
        final String category = db.getCategoryName(Category);
        final String price = Float.toString(Price);
        final byte[]bookimg = book.getBtImage();
        final Intent intent = new Intent(c,BookDetails);


        Bitmap bitmap = BitmapFactory.decodeByteArray(bookimg,0,bookimg.length);
        holder.book.setImageBitmap(bitmap);
        holder.Tvprice.setText(price);
        holder.Tvtitle.setText(Title);
        holder.TvDescription.setText(Description);
        holder.Tvcategorie.setText(category);
        holder.book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                sendDetailsBook(
                        ""+Id,
                        bookimg,
                        ""+ISBN,
                        ""+Title,
                        ""+Description,
                        ""+category,
                        ""+price,
                        intent
                );
            }
        });
    }

    public void sendDetailsBook(String id,byte[]image,String isbn,String titre,String description,String cat,String prix,Intent i){

        //Intent intent = new Intent(c,BookDetails.class);
        i.putExtra("id",id);
        i.putExtra("image",image);
        i.putExtra("isbn",isbn);
        i.putExtra("titre",titre);
        i.putExtra("description",description);
        i.putExtra("catego",cat);
        i.putExtra("prix",prix);
        i.putExtra("userDetails",user);
        c.startActivity(i);
    }

    @Override
    public int getItemCount() {
        return ListofObject.size();
    }

    class Holder extends RecyclerView.ViewHolder{

        private ImageView book;
        private TextView Tvuser,Tvprice,Tvcategorie,Tvquantite,Tvtitle,TVisbn,TvDescription;

        public Holder(View itemview){
            super(itemview);

            book = itemview.findViewById(R.id.imgv_book);
            Tvprice = itemview.findViewById(R.id.tv_price);
            Tvcategorie = itemview.findViewById(R.id.tv_category);
            TvDescription = itemview.findViewById(R.id.tv_description);
            Tvtitle = itemview.findViewById(R.id.tv_title);


        }
    }
}
