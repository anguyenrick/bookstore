package com.example.bookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CharSequence text;
    private DBhelper db;
    private EditText Epseudo,Email,Eadress,Ephone,Epwd,EconfPwd;
    private Button btnSubmit;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Epseudo=findViewById(R.id.input_pseudo);
        Email=findViewById(R.id.input_email);
        Eadress=findViewById(R.id.input_adress);
        Ephone=findViewById(R.id.input_tel);
        Epwd=findViewById(R.id.input_password);
        EconfPwd=findViewById(R.id.input_confirm_password);
        btnSubmit=findViewById(R.id.btn_submit);
        db = new DBhelper(this);
        btnSubmit.setEnabled(false);
        btnSubmit.setBackgroundResource(R.color.darkInput);


        //add text watcher to input
        Epseudo.addTextChangedListener(signInTextWatcher);
        Email.addTextChangedListener(signInTextWatcher);
        Eadress.addTextChangedListener(signInTextWatcher);
        Ephone.addTextChangedListener(signInTextWatcher);
        Epwd.addTextChangedListener(signInTextWatcher);
        EconfPwd.addTextChangedListener(signInTextWatcher);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pseudo=Epseudo.getText().toString().trim();
                String mail=Email.getText().toString().trim();
                String adress=Eadress.getText().toString().trim();
                String phone = Ephone.getText().toString().trim();
                String pwd = Epwd.getText().toString().trim();
                String confPwd = EconfPwd.getText().toString().trim();

                /*if(!(Epseudo.getText().toString().isEmpty()&&Email.getText().toString().isEmpty() && Ephone.getText().toString().isEmpty() && EconfPwd.getText().toString().isEmpty()&&Epwd.getText().toString().isEmpty())){*/

                    if(mail.contains("@")){

                        //check email in DB
                        Boolean chkEmail = db.CheckMail(mail);
                        Boolean chkPseudo = db.CheckPseudo(pseudo);

                        if(chkEmail==true && chkPseudo==true){


                            if(pwd.equals(confPwd)){
                                user = new User(mail,pseudo,pwd,phone,adress);
                                Boolean insert = db.addUser(user);
                            if(insert){
                               text="Inscription réussie";
                               MakeToast(text);
                               Intent i = new Intent(MainActivity.this,Main.class);//MainActivity.this
                                i.putExtra("userDetails",user);
                               startActivity(i);
                            }
                            }else{
                                text="Les 2 mots de passe ne correspondent pas";
                                MakeToast(text);
                            }
                        }else{
                            text="L'email ou le pseudo est déjà pris";
                            MakeToast(text);
                        }

                    }else{

                        text="Email n'existe pas";
                        MakeToast(text);
                    }
                /*}else{
                      text="Veuillez remplir tous les champs";
                      MakeToast(text);
                }*/
            }
        });

    }

    private TextWatcher signInTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //trim():doesn't take white space into account
            String pseudo=Epseudo.getText().toString().trim();
            String mail=Email.getText().toString().trim();
            String address=Eadress.getText().toString().trim();
            String phone = Ephone.getText().toString().trim();
            String pwd = Epwd.getText().toString().trim();
            String confPwd = EconfPwd.getText().toString().trim();

            if(!pseudo.isEmpty()&&!mail.isEmpty()&&!address.isEmpty()&&!phone.isEmpty()&&!pwd.isEmpty()&&!confPwd.isEmpty()){
                btnSubmit.setBackgroundResource(R.color.input);
                btnSubmit.setEnabled(true);
            }

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void ToLogin(View view){

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void MakeToast(CharSequence text){

        Context context = getApplicationContext();
        int duration=Toast.LENGTH_SHORT;
        Toast t = Toast.makeText(context,text,duration);
        t.show();
    }




}


