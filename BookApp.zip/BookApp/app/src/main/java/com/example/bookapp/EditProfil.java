package com.example.bookapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EditProfil extends AppCompatActivity {

    private TextView tvAnnuler;
    private EditText Epseudo,Email,Etelephone,Epwd,Eadress;
    private User user;
    private Button btnSave,btndelete;
    private DBhelper db;
    private String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profil);

        Epseudo = findViewById(R.id.edtxt_pseudo);
        Email = findViewById(R.id.edtxt_mail);
        Eadress=findViewById(R.id.edtxt_adress);
        Etelephone=findViewById(R.id.edtxt_tel);
        Epwd=findViewById(R.id.edtxt_pwd);
        btnSave = findViewById(R.id.btn_saveEdit);
        btndelete = findViewById(R.id.btn_delete);
        db = new DBhelper(this);
        btnSave.setEnabled(false);
        btnSave.setBackgroundResource(R.color.darkInput);

        Epseudo.addTextChangedListener(editTextWatcher);
        Email.addTextChangedListener(editTextWatcher);
        Eadress.addTextChangedListener(editTextWatcher);
        Etelephone.addTextChangedListener(editTextWatcher);
        Epwd.addTextChangedListener(editTextWatcher);


        Intent intent = getIntent();
        if(intent!=null){
            user = (User) intent.getSerializableExtra("userDetails");//besoin du Cast
            DisplayUsersInfo(user);
        }else{
            Toast.makeText(this, "Echec de récupération d'info", Toast.LENGTH_SHORT).show();
        }
        UpdateUser();
        DeleteUser();





        /*tvAnnuler = findViewById(R.id.tv_annuler);

        tvAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Profil p = new Profil();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container_myprofil,p).commit();
            }
        });*/
    }

    private TextWatcher editTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            btnSave.setEnabled(true);
            btnSave.setBackgroundResource(R.color.input);
        }
    };

    private void DisplayUsersInfo(User user){
        Epseudo.setText(user.getPseudo());
        Email.setText(user.getMail());
        Eadress.setText(user.getAdress());
        Etelephone.setText(user.getPhone());
        Epwd.setText(user.getPassword());
    }

    private void MakeToast(String text){

        Context context = getApplicationContext();
        int duration=Toast.LENGTH_SHORT;
        Toast t = Toast.makeText(context,text,duration);
        t.show();
    }

    public void UpdateUser(){
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pseudo = Epseudo.getText().toString().trim();
                String mail = Email.getText().toString().trim();
                String adress = Eadress.getText().toString().trim();
                String tel = Etelephone.getText().toString().trim();
                String pwd = Epwd.getText().toString().trim();

                if(!pseudo.isEmpty()&&!mail.isEmpty()&&!adress.isEmpty()&&!tel.isEmpty()&&!pwd.isEmpty()){

                    if(!mail.contains("@")){
                        text="Email non valide";
                        MakeToast(text);
                    }else{
                        Boolean update = db.updateUser(user.getId(),mail,pseudo,pwd,tel,adress);

                        if(update){
                            text="Données sauvegardées";
                            MakeToast(text);
                            Intent i = new Intent(EditProfil.this,LoginActivity.class);
                            text=" Veuillez-vous reconnecter";
                            MakeToast(text);
                            startActivity(i);
                        }else{
                            text="Erreur de sauvegarde";
                            MakeToast(text);
                        }
                    }

                }

            }
        });
    }

    public void DeleteUser(){
        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(EditProfil.this);
                builder.setTitle("Suppression de votre compte ");
                builder.setMessage("Etes-vous sûr de votre décision?");
                builder.setCancelable(false);

                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Boolean delete = db.deleteUser(user);

                        if(delete){
                            Intent i = new Intent(EditProfil.this,LoginActivity.class);
                            startActivity(i);
                            text="Au revoir";
                            MakeToast(text);
                        }else{
                            text="Erreur de suppression";
                            MakeToast(text);
                        }

                    }
                });

                builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.create().show();

            }
        });
    }
}
