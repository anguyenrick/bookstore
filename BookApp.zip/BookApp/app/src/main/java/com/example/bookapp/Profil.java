package com.example.bookapp;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class Profil extends Fragment {

    private TextView tvMyProfil;
    private Button btnLogout;
    private User user;
    private Main mainActivity;

    public Profil() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View view= inflater.inflate(R.layout.fragment_profil, container, false);
        tvMyProfil = view.findViewById(R.id.tv_EditProfil);
        btnLogout = view.findViewById(R.id.btn_log_out);

        //Recuperation des infos du user depuis le Main-----------------------------------
        mainActivity = (Main)getActivity();
        user = mainActivity.getUserFromMain();
        //Toast.makeText(getActivity(), user.getPseudo(), Toast.LENGTH_SHORT).show();



        tvMyProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),EditProfil.class);
                i.putExtra("userDetails",user);
                startActivity(i);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),LoginActivity.class);
                startActivity(i);
            }
        });

        return view;
    }


}
